(function(){(()=>{if(globalThis.__easyReaderContentInstalled)return;globalThis.__easyReaderContentInstalled=!0;function a(){const t=document.cloneNode(!0);t.querySelectorAll('script, style, noscript, nav, [hidden], [aria-hidden="true"], [role="navigation"]').forEach(e=>e.remove());let n=t.querySelector('main, [role="main"], article')||t.body;try{const e=globalThis.Readability;if(n===t.body&&typeof e=="function"){const r=new e(t.cloneNode(!0)).parse();r!=null&&r.content&&(n=new DOMParser().parseFromString(r.content,"text/html").body)}}catch{}return n.querySelectorAll("p, h1, h2, h3, h4, li, tr, section, div, aside, footer, br").forEach(e=>e.append(`
`)),n.querySelectorAll("td, th").forEach(e=>e.append(" | ")),(n.textContent||"").replace(/[\t ]+/g," ").replace(/\n\s*\n/g,`

`).trim()}chrome.runtime.onMessage.addListener((t,n,o)=>{t.type==="CRAWL_PAGE_TEXT"&&o({text:a()})})})();
})()
