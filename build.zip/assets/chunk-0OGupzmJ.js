import{c as t,j as e,R as r}from"./chunk-BW4HFQ8H.js";import{R as o}from"./chunk-L7ZpNCPK.js";t.createRoot(document.getElementById("app")).render(e.jsx(r.StrictMode,{children:e.jsx(o,{})}));
